## CS166 Project Phase 3

### Collaboration details
In terms of collaboration, we allowed each other to work on whichever function was not currently finished yet but to make sure that we divided it evenly so once a person was done with an equal amount, they stopped and just help guide the other person during confusion and vice versa.

## Assumptions:
- new objects have a unique ID st. it is 1 + the current highest ID value
- price can only have two decimal values as to maintain correct monetary input
- tickets sold can be more than available due to there being a waitlist
- Cruises date does not track time

## Joshua:
AddShip:
```
String query = "INSERT INTO Ship (id, make, model, age, seats) VALUES (";
query += sid + ", ";
query += "'" + ship_make + "', ";
query += "'" +ship_model + "', ";
query += ship_age + ", ";
query += free_seats + ");";    
```
AddCaptain:
```
String cid_q = "SELECT MAX(C.id) FROM Captain C";
String res = esql.executeQueryAndReturnResult(cid_q).get(0).get(0);
String cid = String.valueOf(Integer.parseInt(res)+1);
String query = "INSERT INTO Captain (id, fullname, nationality) VALUES (";
query += cid + ", ";
query += "'" + capt_name + "', ";
query += "'" +capt_nat + "'); ";    
```      
AddCruise:
 ```
String q_cnum = "SELECT MAX(C.c_num) FROM Cruise C;";
String res = esql.executeQueryAndReturnResult(q_cnum).get(0).get(0);
String c_num = String.valueOf(Integer.parseInt(res)+1);
String query = "INSERT INTO Cruise VALUES (";
query += c_num + ", ";
query += tix_price + ", ";
query += tix_sold + ", ";
query += stop_num + ", ";
query += "'" + date_of_dep + "', ";
query += "'" + date_of_arr + "', ";
query += "'" + arr_p_code + "', ";
query += "'" +dep_p_code + "'); ";	 
 ```
        

## Kiet 
BookCruise:
 ```
String query = "INSERT INTO  Reservation (rnum, ccid, cid, stat) VALUES (";
query += rnum + ", ";
query += c_id + ", ";
query += cruise_num + ", ";
query += "'" + stat + "');";	
```
ListNumberOfAvailableSeats:
```
String seats_q = "SELECT C.num_sold, S.seats FROM Cruise C, Ship S, CruiseInfo CI WHERE CI.cruise_id = "+c_num+" AND CI.cruise_id = C.c_num AND C.actual_departure_date = '"+dep_date+"' AND CI.ship_id = S.id;";   
```   
ListsTotalNumberOfRepairsPerShip:
```
String query = "SELECT S.id as Ship_ID, COUNT(R.rid) as Repairs_Made FROM Ship S, Repairs R WHERE S.id = R.ship_id GROUP BY S.id ORDER BY COUNT(R.rid) DESC;";    
```    
FindPassengersCountWithStatus:
```
String query = "SELECT R.stat, COUNT(DISTINCT R.ccid) FROM Reservation R WHERE cid = "+c_num+" AND stat = '"+stat+"' GROUP BY R.stat;";    
```
